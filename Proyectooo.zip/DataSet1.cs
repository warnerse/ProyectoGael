﻿namespace WindowsFormsApp1
{


    partial class DataSet1
    {
    }
}

namespace WindowsFormsApp1.DataSet1TableAdapters {
    
    
    public partial class TCasoTableAdapter {
    }
}
