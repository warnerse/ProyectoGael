﻿namespace WindowsFormsApp1
{
    partial class ModificarTecnico
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblModTecnico = new System.Windows.Forms.Label();
            this.lblModNombre = new System.Windows.Forms.Label();
            this.lblModApellido = new System.Windows.Forms.Label();
            this.lblModEsAdmin = new System.Windows.Forms.Label();
            this.lblModContrasena = new System.Windows.Forms.Label();
            this.lblModTecnicoId = new System.Windows.Forms.Label();
            this.txtModNombre = new System.Windows.Forms.TextBox();
            this.txtModApellido = new System.Windows.Forms.TextBox();
            this.txtModContrasena = new System.Windows.Forms.TextBox();
            this.btnModActualizar = new System.Windows.Forms.Button();
            this.chkAdmin = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // lblModTecnico
            // 
            this.lblModTecnico.AutoSize = true;
            this.lblModTecnico.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblModTecnico.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblModTecnico.Location = new System.Drawing.Point(40, 9);
            this.lblModTecnico.Name = "lblModTecnico";
            this.lblModTecnico.Size = new System.Drawing.Size(108, 22);
            this.lblModTecnico.TabIndex = 0;
            this.lblModTecnico.Text = "ID Tecnico";
            // 
            // lblModNombre
            // 
            this.lblModNombre.AutoSize = true;
            this.lblModNombre.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblModNombre.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblModNombre.Location = new System.Drawing.Point(288, 79);
            this.lblModNombre.Name = "lblModNombre";
            this.lblModNombre.Size = new System.Drawing.Size(83, 22);
            this.lblModNombre.TabIndex = 1;
            this.lblModNombre.Text = "Nombre";
            // 
            // lblModApellido
            // 
            this.lblModApellido.AutoSize = true;
            this.lblModApellido.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblModApellido.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblModApellido.Location = new System.Drawing.Point(288, 167);
            this.lblModApellido.Name = "lblModApellido";
            this.lblModApellido.Size = new System.Drawing.Size(85, 22);
            this.lblModApellido.TabIndex = 2;
            this.lblModApellido.Text = "Apellido";
            // 
            // lblModEsAdmin
            // 
            this.lblModEsAdmin.AutoSize = true;
            this.lblModEsAdmin.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblModEsAdmin.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblModEsAdmin.Location = new System.Drawing.Point(245, 379);
            this.lblModEsAdmin.Name = "lblModEsAdmin";
            this.lblModEsAdmin.Size = new System.Drawing.Size(181, 22);
            this.lblModEsAdmin.TabIndex = 3;
            this.lblModEsAdmin.Text = "Es administrador?";
            // 
            // lblModContrasena
            // 
            this.lblModContrasena.AutoSize = true;
            this.lblModContrasena.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblModContrasena.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblModContrasena.Location = new System.Drawing.Point(269, 277);
            this.lblModContrasena.Name = "lblModContrasena";
            this.lblModContrasena.Size = new System.Drawing.Size(118, 22);
            this.lblModContrasena.TabIndex = 4;
            this.lblModContrasena.Text = "Contraseña";
            // 
            // lblModTecnicoId
            // 
            this.lblModTecnicoId.AutoSize = true;
            this.lblModTecnicoId.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblModTecnicoId.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblModTecnicoId.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.lblModTecnicoId.Location = new System.Drawing.Point(49, 43);
            this.lblModTecnicoId.Name = "lblModTecnicoId";
            this.lblModTecnicoId.Size = new System.Drawing.Size(83, 23);
            this.lblModTecnicoId.TabIndex = 5;
            this.lblModTecnicoId.Text = "ID Tecnico";
            // 
            // txtModNombre
            // 
            this.txtModNombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtModNombre.Location = new System.Drawing.Point(161, 109);
            this.txtModNombre.Name = "txtModNombre";
            this.txtModNombre.Size = new System.Drawing.Size(342, 29);
            this.txtModNombre.TabIndex = 6;
            // 
            // txtModApellido
            // 
            this.txtModApellido.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtModApellido.Location = new System.Drawing.Point(161, 204);
            this.txtModApellido.Name = "txtModApellido";
            this.txtModApellido.Size = new System.Drawing.Size(342, 29);
            this.txtModApellido.TabIndex = 7;
            // 
            // txtModContrasena
            // 
            this.txtModContrasena.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtModContrasena.Location = new System.Drawing.Point(161, 302);
            this.txtModContrasena.Name = "txtModContrasena";
            this.txtModContrasena.Size = new System.Drawing.Size(342, 29);
            this.txtModContrasena.TabIndex = 8;
            // 
            // btnModActualizar
            // 
            this.btnModActualizar.BackColor = System.Drawing.SystemColors.HighlightText;
            this.btnModActualizar.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnModActualizar.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnModActualizar.Location = new System.Drawing.Point(273, 449);
            this.btnModActualizar.Name = "btnModActualizar";
            this.btnModActualizar.Size = new System.Drawing.Size(94, 31);
            this.btnModActualizar.TabIndex = 9;
            this.btnModActualizar.Text = "Actualizar";
            this.btnModActualizar.UseVisualStyleBackColor = false;
            // 
            // chkAdmin
            // 
            this.chkAdmin.AutoSize = true;
            this.chkAdmin.Location = new System.Drawing.Point(319, 404);
            this.chkAdmin.Name = "chkAdmin";
            this.chkAdmin.Size = new System.Drawing.Size(15, 14);
            this.chkAdmin.TabIndex = 10;
            this.chkAdmin.UseVisualStyleBackColor = true;
            // 
            // ModificarTecnico
            // 
            this.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.ClientSize = new System.Drawing.Size(672, 556);
            this.Controls.Add(this.chkAdmin);
            this.Controls.Add(this.btnModActualizar);
            this.Controls.Add(this.txtModContrasena);
            this.Controls.Add(this.txtModApellido);
            this.Controls.Add(this.txtModNombre);
            this.Controls.Add(this.lblModTecnicoId);
            this.Controls.Add(this.lblModContrasena);
            this.Controls.Add(this.lblModEsAdmin);
            this.Controls.Add(this.lblModApellido);
            this.Controls.Add(this.lblModNombre);
            this.Controls.Add(this.lblModTecnico);
            this.Name = "ModificarTecnico";
            this.Load += new System.EventHandler(this.Modificar_Load_1);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        public System.Windows.Forms.TextBox txtCorreo;
        public System.Windows.Forms.TextBox txtObservaciones;
        public System.Windows.Forms.Label lblCaso;
        public System.Windows.Forms.Label lblUsuario;
        public System.Windows.Forms.Label lblFecha;
        private System.Windows.Forms.ComboBox cboCategoria;
        private System.Windows.Forms.ComboBox cboEstado;
        private System.Windows.Forms.ComboBox cboTecnico;
        public System.Windows.Forms.Label lblCategoria;
        public System.Windows.Forms.Label lblEstado;
        public System.Windows.Forms.Label lblTecnico;
        public System.Windows.Forms.Label lblDetalle;
        private System.Windows.Forms.Button btnActualizar;
        private System.Windows.Forms.Label lblModTecnico;
        private System.Windows.Forms.Label lblModNombre;
        private System.Windows.Forms.Label lblModApellido;
        private System.Windows.Forms.Label lblModEsAdmin;
        private System.Windows.Forms.Label lblModContrasena;
        public System.Windows.Forms.Label lblModTecnicoId;
        public System.Windows.Forms.TextBox txtModNombre;
        public System.Windows.Forms.TextBox txtModApellido;
        public System.Windows.Forms.TextBox txtModContrasena;
        private System.Windows.Forms.Button btnModActualizar;
        public System.Windows.Forms.CheckBox chkAdmin;
    }
}