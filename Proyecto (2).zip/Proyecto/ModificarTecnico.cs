﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class ModificarTecnico : Form
    {
        DBAccess objDBAccess = new DBAccess();
        public ModificarTecnico()
        {
            InitializeComponent();
        }

        private void Modificar_Load_1(object sender, EventArgs e)
        {
            
        }

        private void btnModActualizar_Click(object sender, EventArgs e)
        {
            string nombre = txtModNombre.Text;
            int usuario = Int32.Parse(lblModTecnicoId.Text);
            string apellido = txtModApellido.Text;
            string contraseña = txtModContrasena.Text;



            SqlCommand updateUsuario = new SqlCommand("UPDATE TUsuario SET Nombre = @nombre, Apellido = @apellido, contraseña = @contraseña where IdUsuario = @usuario");

            updateUsuario.Parameters.AddWithValue("@nombre", nombre);
            updateUsuario.Parameters.AddWithValue("@usuario", usuario);
            updateUsuario.Parameters.AddWithValue("@apellido", apellido);
            updateUsuario.Parameters.AddWithValue("@contraseña", contraseña);

            objDBAccess.executeQuery(updateUsuario);
            MessageBox.Show("Usuario Actualizado");





        }
    }
}
