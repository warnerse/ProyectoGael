﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Bitacorr : Form
    {
        DBAccess objDBAccess = new DBAccess();
        DataTable DTbitacora = new DataTable();
        public Bitacorr()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dataSet1.TBitacora' table. You can move, or remove it, as needed.
           // this.tBitacoraTableAdapter.Fill(this.dataSet1.TBitacora);
            string queryBitacora = "select * from TBitacora";
            objDBAccess.readDatathroughAdapter(queryBitacora, DTbitacora);

            dataGridView1.DataSource = DTbitacora;
        }
    }
}
