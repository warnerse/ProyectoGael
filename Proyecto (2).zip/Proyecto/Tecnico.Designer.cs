﻿namespace WindowsFormsApp1
{
    partial class Tecnico
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tEstadoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet11 = new WindowsFormsApp1.DataSet1();
            this.btnActualizar = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.dataGridViewTecnico = new System.Windows.Forms.DataGridView();
            this.tCasoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet1 = new WindowsFormsApp1.DataSet1();
            this.tCasoTableAdapter = new WindowsFormsApp1.DataSet1TableAdapters.TCasoTableAdapter();
            this.tEstadoTableAdapter = new WindowsFormsApp1.DataSet1TableAdapters.TEstadoTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.tEstadoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTecnico)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tCasoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // tEstadoBindingSource
            // 
            this.tEstadoBindingSource.DataMember = "TEstado";
            this.tEstadoBindingSource.DataSource = this.dataSet11;
            // 
            // dataSet11
            // 
            this.dataSet11.DataSetName = "DataSet1";
            this.dataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // btnActualizar
            // 
            this.btnActualizar.Location = new System.Drawing.Point(1557, 278);
            this.btnActualizar.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnActualizar.Name = "btnActualizar";
            this.btnActualizar.Size = new System.Drawing.Size(112, 97);
            this.btnActualizar.TabIndex = 2;
            this.btnActualizar.Text = "Actualizar";
            this.btnActualizar.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(153, 457);
            this.button2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(112, 35);
            this.button2.TabIndex = 3;
            this.button2.Text = "Modificar";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(306, 457);
            this.button3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(112, 35);
            this.button3.TabIndex = 4;
            this.button3.Text = "Finalizar";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(452, 457);
            this.button4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(112, 35);
            this.button4.TabIndex = 5;
            this.button4.Text = "Ver";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // dataGridViewTecnico
            // 
            this.dataGridViewTecnico.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewTecnico.Location = new System.Drawing.Point(154, 217);
            this.dataGridViewTecnico.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridViewTecnico.Name = "dataGridViewTecnico";
            this.dataGridViewTecnico.RowHeadersWidth = 62;
            this.dataGridViewTecnico.Size = new System.Drawing.Size(1394, 231);
            this.dataGridViewTecnico.TabIndex = 6;
            this.dataGridViewTecnico.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewTecnico_CellContentClick);
            // 
            // tCasoBindingSource
            // 
            this.tCasoBindingSource.DataMember = "TCaso";
            this.tCasoBindingSource.DataSource = this.dataSet1;
            // 
            // dataSet1
            // 
            this.dataSet1.DataSetName = "DataSet1";
            this.dataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tCasoTableAdapter
            // 
            this.tCasoTableAdapter.ClearBeforeFill = true;
            // 
            // tEstadoTableAdapter
            // 
            this.tEstadoTableAdapter.ClearBeforeFill = true;
            // 
            // Tecnico
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1732, 692);
            this.Controls.Add(this.dataGridViewTecnico);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btnActualizar);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Tecnico";
            this.Text = "Tecnico";
            this.Load += new System.EventHandler(this.Tecnico_Load);
            ((System.ComponentModel.ISupportInitialize)(this.tEstadoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTecnico)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tCasoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnActualizar;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.DataGridView dataGridViewTecnico;
        private DataSet1 dataSet1;
        private System.Windows.Forms.BindingSource tCasoBindingSource;
        private DataSet1TableAdapters.TCasoTableAdapter tCasoTableAdapter;
        private DataSet1 dataSet11;
        private System.Windows.Forms.BindingSource tEstadoBindingSource;
        private DataSet1TableAdapters.TEstadoTableAdapter tEstadoTableAdapter;
    }
}