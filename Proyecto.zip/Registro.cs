﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Registro : Form
    {
        public Registro()
        {
            InitializeComponent();
        }

        private void Registro_Load(object sender, EventArgs e)
        {

        }

        private void btnAtras_Click(object sender, EventArgs e)
        {
            Form btnAtras = new Bienvenida();
            btnAtras.Show();
        }

        private void btnIngresar_Click(object sender, EventArgs e)
        {
            if (txtContraseña.Text != "" && txtID.Text != "")
            {
                DataTable dt = new DataTable();
                dt = tUsuarioTableAdapter1.GetDataByUsuario(Int32.Parse(txtID.Text),Int32.Parse(txtContraseña.Text));
                if (dt.Rows.Count > 0)
                {
                    String usuario = dt.Rows[0][3].ToString();
                    if(usuario == "True"){
                        Administrador ventana = new Administrador();
                        ventana.Show();
                        this.Close();
                    
                    }
                    else{ 
                        Tecnico ventana = new Tecnico();
                        ventana.Show();
                        this.Close();
                    }
                    
                }//fin if
            }

        }
    }
}
