﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class CrearCaso : Form
    {
        public CrearCaso()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void CrearCaso_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'dataSet1.TCategoria' Puede moverla o quitarla según sea necesario.
            this.tCategoriaTableAdapter.Fill(this.dataSet1.TCategoria);

        }

        private void btnAtrasCrear_Click(object sender, EventArgs e)
        {
             Form btnAtrasCrear = new Bienvenida();
            btnAtrasCrear.Show();
        }

        private void btnEnviar_Click(object sender, EventArgs e)
        {
            tCasoTableAdapter1.InsertQuery(txtNombre.Text, (int)cboCategoria.SelectedValue, txtCorreo.Text, txtDetalle.Text);
            MessageBox.Show("El caso fue enviado con exito");
        }
    }
}
